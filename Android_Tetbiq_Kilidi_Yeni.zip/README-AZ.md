# Tətbiq Kilidi — Android v1 (sınaq layihəsi)

Bu layihə **Android tətbiqlərini kilidləmək** üçün hazırlanmış ilkin versiyadır.

## Funksiyalar

- Qurğuda quraşdırılmış tətbiqləri seçmək və kilidləmək.
- Birinci mərhələ: 4–8 rəqəmli PIN **və ya** 3×3 naxış.
- İkinci mərhələ: Android sisteminin dəstəklədiyi biometrik yoxlama (üz və/və ya barmaq izi).
- Hər iki mərhələ uğurla tamamlanmadan kilid açılmır.
- Ekran söndükdə açılmış sessiya sıfırlanır.
- Şəbəkə icazəsi yoxdur; kod PİN/naxışın şifrələnmiş törəmə hash dəyərini saxlayır, xam dəyəri saxlamır.

## APK almaq — GitHub Actions

1. GitHub-da boş `TetbiqKilidi` repozitoriyası yaradın.
2. Bu ZIP-i çıxarın və **içindəki fayl/qovluqları** repozitoriyanın kökünə yükləyin. `.github/workflows/android-apk.yml` faylı da yüklənməlidir.
3. Repozitoriyada `Actions` bölməsinə keçin; `Tetbiq Kilidi APK` iş axınını başladın.
4. Yaşıl `Success` olarsa, ən altdakı `Artifacts` bölməsindən **TetbiqKilidi-v1-APK** arxivini endirin.
5. Arxivin içindəki `TetbiqKilidi-v1.apk` faylını telefona quraşdırın.

GitHub Actions yalnız uğurlu yığımdan sonra APK yaradır. Bu ZIP **APK faylı deyil**.

## Telefon ayarları

1. Tətbiqi açın; PIN və ya naxış qurun.
2. Biometrik testdən keçin. Telefonun Android BiometricPrompt sistemi üz tanımanı təqdim etmirsə, barmaq izi işləyə bilər. Heç bir biometrik üsul dəstəklənmirsə, hazırkı v1-də kilid aktiv olmur.
3. `Əlçatanlıq / Accessibility` bölməsində **Tətbiq Kilidi** xidmətini əl ilə aktiv edin. Xidmət yalnız ön plandakı tətbiqin paket adını görür, ekran mətnlərini oxumur.
4. Kilidləmək istədiyiniz tətbiqləri işarələyin.
5. Tətbiqi açıb yoxlayın: birinci PIN/naxış, sonra biometrik təsdiq tələb olunur.

## Vacib məhdudiyyətlər

- Bu, Android əməliyyat sisteminin yerli təhlükəsizlik kilidi deyil. İstifadəçi əlçatanlıq xidmətini deaktiv edə, tətbiqi silə və ya bəzi telefonlarda arxa fon məhdudiyyətləri ilə qorumanı dayandıra bilər.
- Xiaomi/MIUI/HyperOS versiyalarında əlavə avtomatik başlatma/arxa fon icazələri tələb oluna bilər.
- Ekran sönəndə yenidən kilidlənmə və digər funksiyalar **real telefonda hələ sınaqdan keçirilməyib**.
- Layihə burada Android SDK olmadan hazırlanıb, **Gradle ilə kompilyasiya testi aparılmayıb**.
- İlk versiyanı şəxsi sınaq üçün istifadə edin; həssas məlumatların qorunmasını yalnız buna etibar etməyin.
