package az.iftixar.tetbiqkilidi;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends Activity {
    private LockPrefs prefs;
    private LinearLayout page;
    private CancellationSignal checkCancellation;
    private boolean settingsAuthPending;
    private static final int SETTINGS_AUTH_REQUEST = 92;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new LockPrefs(this);
        verifySettingsAccess();
    }

    @Override protected void onResume() {
        super.onResume();
        if (page != null && !settingsAuthPending) {
            if (prefs.hasCredential() && prefs.biometricReady() && !SessionState.unlocked)
                verifySettingsAccess();
            else showPage();
        }
    }

    private void verifySettingsAccess() {
        if (prefs.hasCredential() && prefs.biometricReady() && !SessionState.unlocked) {
            if (!settingsAuthPending) {
                settingsAuthPending = true;
                startActivityForResult(new Intent(this, UnlockActivity.class), SETTINGS_AUTH_REQUEST);
            }
        } else {
            showPage();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == SETTINGS_AUTH_REQUEST) {
            settingsAuthPending = false;
            if (SessionState.unlocked) showPage();
            else finish();
        }
    }
    @Override protected void onPause() {
        if (checkCancellation != null) checkCancellation.cancel();
        checkCancellation = null;
        super.onPause();
    }

    private void showPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        page = Ui.column(this, 20);
        scroll.addView(page);
        setContentView(scroll);

        page.addView(Ui.title(this, "🔐 Tətbiq Kilidi"));
        page.addView(Ui.text(this, "PIN və ya naxış + telefonun biometrik yoxlaması. Hər ikisi tələb olunur.", 14, Ui.MUTED));
        String modeText = prefs.hasCredential() ? (prefs.mode().equals("pin") ? "PIN hazırdır" : "Naxış hazırdır") : "Hələ kilid qurulmayıb";
        page.addView(Ui.text(this, "1. Birinci mərhələ: " + modeText, 16, Ui.TEXT));

        android.widget.Button pin = Ui.button(this, "PIN qur / dəyiş");
        pin.setOnClickListener(v -> pinDialog());
        page.addView(pin);
        android.widget.Button pattern = Ui.button(this, "Naxış qur / dəyiş");
        pattern.setOnClickListener(v -> startActivity(new Intent(this, PatternSetupActivity.class)));
        page.addView(pattern);

        page.addView(Ui.text(this,
                "2. Biometrik yoxlama: " + (prefs.biometricReady() ? "Təsdiqləndi ✓" : "Test edilməyib"), 16,
                prefs.biometricReady() ? Color.rgb(132, 230, 177) : Ui.TEXT));
        android.widget.Button bio = Ui.button(this, "Üz / barmaq izi yoxlamasını sına");
        bio.setEnabled(prefs.hasCredential());
        bio.setOnClickListener(v -> checkBiometrics());
        page.addView(bio);
        page.addView(Ui.text(this,
                "Qeyd: Telefonun biometrik sistemi hansı üsulu dəstəkləyirsə (üz və ya barmaq izi), onu istifadə edir.", 13, Ui.MUTED));

        page.addView(Ui.text(this, "3. Tətbiq kilidləmə xidmətini aktiv et", 16, Ui.TEXT));
        page.addView(Ui.text(this,
                "Xidmət: " + (AppLockService.isRunning() ? "Aktiv ✓" : "Aktiv deyil. Ayarlardan açın."), 14, Ui.MUTED));
        android.widget.Button serviceButton = Ui.button(this, "Android → Əlçatanlıq ayarlarını aç");
        serviceButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        page.addView(serviceButton);

        page.addView(Ui.title(this, "Kilidlənəcək tətbiqlər"));
        if (!prefs.hasCredential() || !prefs.biometricReady()) {
            page.addView(Ui.text(this, "Əvvəlcə PIN/naxış qurun və biometrik yoxlamadan keçin.", 14, Ui.MUTED));
        }
        loadAppList();
        page.addView(Ui.text(this,
                "Ekran sönəndə kilid yenidən aktiv olur. Xidmət söndürüləndə qoruma da dayanır. " +
                "Proqram internetə məlumat göndərmir.", 13, Ui.MUTED));
    }

    private void loadAppList() {
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all = pm.queryIntentActivities(launcher, 0);
        List<ResolveInfo> apps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : all) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (!pkg.equals(getPackageName()) && seen.add(pkg)) apps.add(ri);
        }
        apps.sort(Comparator.comparing(ri -> String.valueOf(ri.loadLabel(pm)).toLowerCase()));
        for (ResolveInfo ri : apps) {
            String pkg = ri.activityInfo.packageName;
            CheckBox box = new CheckBox(this);
            box.setText(ri.loadLabel(pm) + "\n" + pkg);
            box.setTextColor(Ui.TEXT);
            box.setTextSize(14);
            box.setPadding(Ui.dp(this, 4), Ui.dp(this, 9), Ui.dp(this, 4), Ui.dp(this, 9));
            box.setChecked(prefs.selectedPackages().contains(pkg));
            box.setEnabled(prefs.hasCredential() && prefs.biometricReady());
            box.setOnCheckedChangeListener((b, checked) -> prefs.setSelected(pkg, checked));
            page.addView(box);
        }
        if (apps.isEmpty()) page.addView(Ui.text(this, "Tətbiqlər tapılmadı.", 14, Ui.MUTED));
    }

    private EditText numericBox(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(Ui.MUTED);
        return e;
    }

    private void pinDialog() {
        LinearLayout form = Ui.column(this, 18);
        EditText a = numericBox("Yeni PIN (4–8 rəqəm)");
        EditText b = numericBox("PIN təkrar");
        form.addView(a); form.addView(b);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("PIN təyin et")
                .setView(form)
                .setPositiveButton("Yadda saxla", null)
                .setNegativeButton("Ləğv et", (d, w) -> {})
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(ignored -> {
            String first = a.getText().toString(), repeat = b.getText().toString();
            if (!first.matches("[0-9]{4,8}")) { a.setError("4–8 rəqəm lazımdır"); return; }
            if (!first.equals(repeat)) { b.setError("PIN-lər uyğun gəlmir"); return; }
            prefs.setCredential("pin", first);
            dialog.dismiss();
            Toast.makeText(this, "PIN saxlanıldı. İndi biometrik yoxlamanı sınayın.", Toast.LENGTH_LONG).show();
            showPage();
        }));
        dialog.show();
    }

    private void checkBiometrics() {
        if (Build.VERSION.SDK_INT >= 30) {
            android.hardware.biometrics.BiometricManager manager =
                    (android.hardware.biometrics.BiometricManager) getSystemService(BIOMETRIC_SERVICE);
            if (manager == null || manager.canAuthenticate(
                    android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    != android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS) {
                Toast.makeText(this, "Telefon ayarlarından üz/barmaq izi əlavə edin. Bu cihazda dəstəklənməyə də bilər.", Toast.LENGTH_LONG).show();
                return;
            }
        }
        try {
            AtomicBoolean completed = new AtomicBoolean(false);
            BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this)
                    .setTitle("Biometrik yoxlama")
                    .setSubtitle("Tətbiqləri qorumaq üçün təsdiqləyin")
                    .setNegativeButton("Ləğv et", getMainExecutor(), (d, which) -> {});
            if (Build.VERSION.SDK_INT >= 30) builder.setAllowedAuthenticators(
                    android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK);
            checkCancellation = new CancellationSignal();
            builder.build().authenticate(checkCancellation, getMainExecutor(),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            if (completed.compareAndSet(false, true)) {
                                prefs.setBiometricReady(true);
                                Toast.makeText(MainActivity.this, "Biometrik yoxlama uğurludur", Toast.LENGTH_SHORT).show();
                                showPage();
                            }
                        }
                        @Override public void onAuthenticationError(int code, CharSequence message) {
                            if (!completed.get()) Toast.makeText(MainActivity.this,
                                    "Yoxlama tamamlanmadı: " + message, Toast.LENGTH_LONG).show();
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(this, "Bu telefonda biometrik təsdiq açıla bilmədi.", Toast.LENGTH_LONG).show();
        }
    }
}
