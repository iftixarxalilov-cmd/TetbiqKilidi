package az.iftixar.tetbiqkilidi;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Simple 3x3 touch pattern with skipped intermediate dots included. */
public final class PatternView extends View {
    public interface Listener { void onPattern(String pattern); }
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Integer> nodes = new ArrayList<>();
    private Listener listener;
    private boolean dragging;
    private float fingerX, fingerY;

    public PatternView(Context c) {
        super(c);
        setBackgroundColor(Ui.BG);
    }

    public void setListener(Listener l) { listener = l; }
    public void clear() { nodes.clear(); dragging = false; invalidate(); }

    private float x(int col) { return getWidth() * (.2f + col * .3f); }
    private float y(int row) { return getHeight() * (.2f + row * .3f); }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int proposed = MeasureSpec.getSize(widthMeasureSpec);
        int side = Math.min(proposed, Ui.dp(getContext(), 330));
        setMeasuredDimension(side, side);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        paint.setStrokeWidth(Ui.dp(getContext(), 5));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Ui.ACCENT);
        for (int i = 1; i < nodes.size(); i++) {
            int a = nodes.get(i - 1), b = nodes.get(i);
            c.drawLine(x(a % 3), y(a / 3), x(b % 3), y(b / 3), paint);
        }
        if (dragging && !nodes.isEmpty()) {
            int a = nodes.get(nodes.size()-1);
            c.drawLine(x(a % 3), y(a / 3), fingerX, fingerY, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        for (int id = 0; id < 9; id++) {
            paint.setColor(nodes.contains(id) ? Ui.ACCENT : Color.rgb(107, 122, 153));
            c.drawCircle(x(id % 3), y(id / 3), Ui.dp(getContext(), nodes.contains(id) ? 14 : 11), paint);
        }
    }

    private void pick(float tx, float ty) {
        int candidate = -1;
        for (int i = 0; i < 9; i++) {
            float dx = tx - x(i % 3), dy = ty - y(i / 3);
            if (dx*dx + dy*dy <= Ui.dp(getContext(), 34) * Ui.dp(getContext(), 34)) {
                candidate = i; break;
            }
        }
        if (candidate < 0 || nodes.contains(candidate)) return;
        if (!nodes.isEmpty()) {
            int last = nodes.get(nodes.size()-1);
            int colStep = candidate % 3 - last % 3;
            int rowStep = candidate / 3 - last / 3;
            if (Math.abs(colStep) == 2 || Math.abs(rowStep) == 2) {
                if (colStep % 2 == 0 && rowStep % 2 == 0) {
                    int middle = ((last / 3 + candidate / 3) / 2)*3
                        + ((last % 3 + candidate % 3) / 2);
                    if (!nodes.contains(middle)) nodes.add(middle);
                }
            }
        }
        nodes.add(candidate);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                nodes.clear(); dragging = true;
                fingerX = event.getX(); fingerY = event.getY();
                pick(fingerX, fingerY); invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging) return false;
                for (int i=0; i<event.getHistorySize(); i++) pick(event.getHistoricalX(i), event.getHistoricalY(i));
                fingerX = event.getX(); fingerY = event.getY();
                pick(fingerX, fingerY); invalidate(); return true;
            case MotionEvent.ACTION_UP:
                if (!dragging) return false;
                pick(event.getX(), event.getY()); dragging = false;
                StringBuilder s = new StringBuilder();
                for (Integer id : nodes) s.append(id);
                if (listener != null) listener.onPattern(s.toString());
                postDelayed(this::clear, 350);
                invalidate(); return true;
            case MotionEvent.ACTION_CANCEL:
                clear(); return true;
            default: return true;
        }
    }
}
