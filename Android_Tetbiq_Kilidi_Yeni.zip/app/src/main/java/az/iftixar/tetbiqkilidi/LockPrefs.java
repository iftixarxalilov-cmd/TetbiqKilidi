package az.iftixar.tetbiqkilidi;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Stores only salted credential hashes, never the PIN or drawn pattern. */
public final class LockPrefs {
    private static final String STORE = "private_lock_settings";
    private final SharedPreferences p;

    public LockPrefs(Context context) {
        p = context.getApplicationContext().getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    public boolean hasCredential() { return p.contains("hash") && p.contains("salt"); }
    public String mode() { return p.getString("mode", "pin"); }
    public boolean biometricReady() { return p.getBoolean("biometric_ok", false); }
    public void setBiometricReady(boolean ready) { p.edit().putBoolean("biometric_ok", ready).apply(); }

    public synchronized void setCredential(String mode, String value) {
        if (!mode.equals("pin") && !mode.equals("pattern")) throw new IllegalArgumentException();
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] hash = derive(value, salt);
        p.edit()
            .putString("mode", mode)
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .putBoolean("biometric_ok", false)
            .apply();
        SessionState.unlocked = false;
    }

    public boolean matches(String value) {
        if (!hasCredential()) return false;
        try {
            byte[] salt = Base64.decode(p.getString("salt", ""), Base64.DEFAULT);
            byte[] expected = Base64.decode(p.getString("hash", ""), Base64.DEFAULT);
            return MessageDigest.isEqual(expected, derive(value, salt));
        } catch (Exception ex) { return false; }
    }

    private static byte[] derive(String value, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(value.toCharArray(), salt, 120_000, 256);
            try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
            finally { spec.clearPassword(); }
        } catch (Exception e) { throw new IllegalStateException("Cannot store credential", e); }
    }

    public Set<String> selectedPackages() {
        return new HashSet<>(p.getStringSet("packages", new HashSet<>()));
    }

    public void setSelected(String packageName, boolean selected) {
        Set<String> set = selectedPackages();
        if (selected) set.add(packageName); else set.remove(packageName);
        p.edit().putStringSet("packages", set).apply();
    }

    public boolean isLocked(String packageName) {
        return hasCredential() && biometricReady() && selectedPackages().contains(packageName);
    }
}
