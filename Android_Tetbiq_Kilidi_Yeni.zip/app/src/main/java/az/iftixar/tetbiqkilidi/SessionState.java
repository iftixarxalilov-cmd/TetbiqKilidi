package az.iftixar.tetbiqkilidi;

/** Memory-only unlock state; screen off resets it. */
public final class SessionState {
    private SessionState() {}
    public static volatile boolean unlocked = false;
}
