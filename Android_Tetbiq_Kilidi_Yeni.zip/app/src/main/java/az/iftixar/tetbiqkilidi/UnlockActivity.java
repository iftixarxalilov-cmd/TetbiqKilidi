package az.iftixar.tetbiqkilidi;

import android.app.Activity;
import android.graphics.Color;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Two independent required factors: user-configured PIN/pattern, then biometric. */
public final class UnlockActivity extends Activity {
    public static final String EXTRA_TARGET = "target_package";
    private LockPrefs prefs;
    private String targetPackage;
    private LinearLayout page;
    private TextView status;
    private boolean firstFactorPassed = false;
    private boolean completed = false;
    private CancellationSignal cancellation;
    private int failedAttempts = 0;
    private long blockedUntil = 0L;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        prefs = new LockPrefs(this);
        targetPackage = getIntent().getStringExtra(EXTRA_TARGET);
        if (!prefs.hasCredential() || !prefs.biometricReady()) {
            finish(); return;
        }
        showFirstFactor();
    }

    private void resetPage(String title, String subtitle) {
        page = Ui.column(this, 24);
        page.setBackgroundColor(Ui.BG);
        page.setGravity(Gravity.CENTER);
        page.addView(Ui.title(this, title));
        status = Ui.text(this, subtitle, 16, Ui.MUTED);
        status.setGravity(Gravity.CENTER);
        page.addView(status);
        setContentView(page);
    }

    private boolean mayAttempt() {
        if (android.os.SystemClock.elapsedRealtime() < blockedUntil) {
            status.setText("Çox sayda səhv cəhd. 30 saniyə sonra yoxlayın.");
            return false;
        }
        return true;
    }

    private void verify(String input) {
        if (!mayAttempt()) return;
        if (prefs.matches(input)) {
            firstFactorPassed = true;
            showBiometricStep();
        } else {
            failedAttempts++;
            if (failedAttempts >= 5) {
                failedAttempts = 0;
                blockedUntil = android.os.SystemClock.elapsedRealtime() + 30000;
                status.setText("5 səhv cəhd. 30 saniyə bloklandı.");
            } else {
                status.setText("Yanlış PIN/naxış. Yenidən cəhd edin.");
            }
        }
    }

    private void showFirstFactor() {
        resetPage("🔐 Birinci mərhələ", prefs.mode().equals("pin") ? "PIN kodunu daxil edin" : "Naxışı çəkin");
        if (prefs.mode().equals("pin")) {
            EditText pin = new EditText(this);
            pin.setSingleLine(true);
            pin.setHint("PIN");
            pin.setTextColor(Ui.TEXT);
            pin.setHintTextColor(Ui.MUTED);
            pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
            page.addView(pin);
            Button next = Ui.button(this, "PIN-i təsdiqlə");
            next.setOnClickListener(v -> {
                String entered = pin.getText().toString();
                pin.getText().clear();
                verify(entered);
            });
            page.addView(next);
        } else {
            PatternView pattern = new PatternView(this);
            page.addView(pattern, new LinearLayout.LayoutParams(-1, Ui.dp(this, 330)));
            pattern.setListener(this::verify);
        }
        Button cancel = Ui.button(this, "Ləğv et");
        cancel.setOnClickListener(v -> finish());
        page.addView(cancel);
    }

    private void showBiometricStep() {
        resetPage("İkinci mərhələ", "PIN/naxış düzgündür. İndi üz və ya barmaq izi ilə təsdiqləyin.");
        Button authenticate = Ui.button(this, "Biometrik təsdiqi aç");
        authenticate.setOnClickListener(v -> beginBiometric());
        page.addView(authenticate);
        Button cancel = Ui.button(this, "Ləğv et");
        cancel.setOnClickListener(v -> finish());
        page.addView(cancel);
        beginBiometric();
    }

    private void beginBiometric() {
        if (!firstFactorPassed || completed || (cancellation != null && !cancellation.isCanceled())) return;
        try {
            BiometricPrompt.Builder builder = new BiometricPrompt.Builder(this)
                    .setTitle("Biometrik təsdiq")
                    .setSubtitle("Tətbiq kilidinin ikinci mərhələsi")
                    .setNegativeButton("Ləğv et", getMainExecutor(), (d, which) -> {});
            if (Build.VERSION.SDK_INT >= 30) {
                builder.setAllowedAuthenticators(
                        android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK);
            }
            cancellation = new CancellationSignal();
            builder.build().authenticate(cancellation, getMainExecutor(),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                            if (!firstFactorPassed || completed) return;
                            completed = true;
                            SessionState.unlocked = true;
                            AppLockService.clearGateAfterAuthentication();
                            Toast.makeText(UnlockActivity.this, "Kilid açıldı", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                        @Override public void onAuthenticationError(int code, CharSequence msg) {
                            cancellation = null;
                            if (!completed && status != null) status.setText("Təsdiq tamamlanmadı: " + msg);
                        }
                        @Override public void onAuthenticationFailed() {
                            if (status != null) status.setText("Biometrik tanıma uğursuz oldu. Yenidən yoxlayın.");
                        }
                    });
        } catch (Exception e) {
            cancellation = null;
            if (status != null) status.setText("Bu cihazda biometrik yoxlama açıla bilmədi.");
        }
    }

    @Override protected void onDestroy() {
        if (cancellation != null) cancellation.cancel();
        if (!completed && targetPackage != null) AppLockService.showGateAfterCancellation(targetPackage);
        super.onDestroy();
    }
}
