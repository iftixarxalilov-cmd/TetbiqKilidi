package az.iftixar.tetbiqkilidi;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public final class PatternSetupActivity extends Activity {
    private String first;
    private TextView hint;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout frame = Ui.column(this, 24);
        frame.setBackgroundColor(Ui.BG);
        frame.setGravity(Gravity.CENTER);
        frame.addView(Ui.title(this, "Naxış kilidi"));
        hint = Ui.text(this, "Ən az 4 nöqtəni birləşdirin", 17, Ui.MUTED);
        hint.setGravity(Gravity.CENTER);
        frame.addView(hint);
        PatternView pattern = new PatternView(this);
        frame.addView(pattern, new LinearLayout.LayoutParams(-1, Ui.dp(this, 330)));
        pattern.setListener(value -> {
            if (value.length() < 4) { hint.setText("Ən az 4 nöqtə seçin"); return; }
            if (first == null) {
                first = value;
                hint.setText("Eyni naxışı təkrar çəkin");
            } else if (first.equals(value)) {
                new LockPrefs(this).setCredential("pattern", value);
                Toast.makeText(this, "Naxış saxlanıldı. Biometrik təsdiqi sınayın.", Toast.LENGTH_LONG).show();
                finish();
            } else {
                first = null;
                hint.setText("Naxışlar fərqlidir. Yenidən başlayın.");
            }
        });
        setContentView(frame);
    }
}
