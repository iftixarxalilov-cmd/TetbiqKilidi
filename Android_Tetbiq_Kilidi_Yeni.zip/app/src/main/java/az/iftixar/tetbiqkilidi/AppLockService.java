package az.iftixar.tetbiqkilidi;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.app.KeyguardManager;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Application gate for user-selected launcher apps. This is an accessibility
 * overlay, not an OS-level lock: users can disable the service in Settings.
 * We only read window package names; never read window content or keystrokes.
 */
public final class AppLockService extends AccessibilityService {
    private static AppLockService activeService;
    private WindowManager windowManager;
    private View gate;
    private LockPrefs prefs;
    private String coveredPackage;
    private String mostRecentApp;
    private BroadcastReceiver screenReceiver;

    public static boolean isRunning() { return activeService != null; }

    public static void clearGateAfterAuthentication() {
        AppLockService s = activeService;
        if (s != null) s.getMainExecutor().execute(s::hideGate);
    }

    public static void showGateAfterCancellation(String pkg) {
        AppLockService s = activeService;
        if (s != null && !SessionState.unlocked && pkg != null)
            s.getMainExecutor().execute(() -> {
                if (s.prefs != null && pkg.equals(s.mostRecentApp) && s.prefs.isLocked(pkg)) s.showGate(pkg);
            });
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        activeService = this;
        SessionState.unlocked = false;
        prefs = new LockPrefs(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        screenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                    SessionState.unlocked = false;
                    hideGate();
                } else if (Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
                    if (mostRecentApp != null && prefs != null && prefs.isLocked(mostRecentApp))
                        showGate(mostRecentApp);
                }
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, RECEIVER_NOT_EXPORTED);
        else registerReceiver(screenReceiver, filter);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        if (prefs == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null) return;
        String name = pkg.toString();
        // Ignore our own application: lock activity/overlay must remain usable.
        if (name.equals(getPackageName())) return;
        if (!name.equals("com.android.systemui")) mostRecentApp = name;
        if (SessionState.unlocked || !prefs.isLocked(name)) {
            hideGate();
        } else {
            showGate(name);
        }
    }

    private void showGate(String packageName) {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (keyguard != null && keyguard.isDeviceLocked()) return;
        if (SessionState.unlocked || prefs == null || !prefs.isLocked(packageName)) return;
        if (gate != null && packageName.equals(coveredPackage)) return;
        hideGate();
        if (windowManager == null) return;
        coveredPackage = packageName;

        LinearLayout panel = Ui.column(this, 28);
        panel.setBackgroundColor(Ui.BG);
        panel.setGravity(Gravity.CENTER);
        panel.addView(Ui.title(this, "🔐 Tətbiq kilidlənib"));
        TextView note = Ui.text(this, "Davam etmək üçün PIN/naxış və biometrik təsdiq lazımdır.", 17, Ui.MUTED);
        note.setGravity(Gravity.CENTER);
        panel.addView(note);
        Button open = Ui.button(this, "İki mərhələli kilidi aç");
        panel.addView(open);
        open.setOnClickListener(v -> {
            // Explicit user interaction allows launching the authentication UI.
            Intent intent = new Intent(this, UnlockActivity.class);
            intent.putExtra(UnlockActivity.EXTRA_TARGET, packageName);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            try {
                startActivity(intent);
                hideGate();
            } catch (Exception ex) {
                note.setText("Açılış məhdudlaşdırılıb. Telefon ayarlarında icazələri yoxlayın.");
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.OPAQUE);
        lp.gravity = Gravity.TOP;
        try {
            windowManager.addView(panel, lp);
            gate = panel;
        } catch (Exception ex) {
            gate = null;
            coveredPackage = null;
        }
    }

    private void hideGate() {
        if (gate != null && windowManager != null) {
            try { windowManager.removeView(gate); } catch (Exception ignored) { }
        }
        gate = null;
        coveredPackage = null;
    }

    @Override public void onInterrupt() { /* Window state monitoring continues when resumed. */ }

    @Override public void onDestroy() {
        hideGate();
        if (screenReceiver != null) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ignored) { }
        }
        if (activeService == this) activeService = null;
        SessionState.unlocked = false;
        super.onDestroy();
    }
}
