package az.iftixar.tetbiqkilidi;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}
    public static final int BG = Color.rgb(12, 17, 30);
    public static final int TEXT = Color.rgb(243, 246, 255);
    public static final int MUTED = Color.rgb(169, 182, 206);
    public static final int ACCENT = Color.rgb(83, 134, 249);

    public static int dp(Context c, float n) {
        return (int) (n * c.getResources().getDisplayMetrics().density + .5f);
    }

    public static TextView text(Context c, String value, int size, int color) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, dp(c, 6), 0, dp(c, 6));
        return t;
    }

    public static TextView title(Context c, String value) {
        TextView t = text(c, value, 25, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    public static Button button(Context c, String value) {
        Button b = new Button(c);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable d = new GradientDrawable();
        d.setColor(ACCENT);
        d.setCornerRadius(dp(c, 13));
        b.setBackground(d);
        b.setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c, 52));
        lp.setMargins(0, dp(c, 9), 0, dp(c, 9));
        b.setLayoutParams(lp);
        return b;
    }

    public static LinearLayout column(Context c, int padding) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, padding), dp(c, padding), dp(c, padding), dp(c, padding));
        return l;
    }
}
